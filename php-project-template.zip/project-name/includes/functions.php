<?php
function greet_user($name) {
    return "Hello, " . htmlspecialchars($name, ENT_QUOTES, 'UTF-8') . "!";
}
?>