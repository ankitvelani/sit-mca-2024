<?php
echo "<header><h1>Welcome to My Website</h1></header>";
?>