# Project Name

This is a Core PHP project structure designed for beginners to organize their scripts properly.

## Features
- Organized directory structure
- Reusable components (header, footer)
- Configurable settings
- Logs and uploads management

## Setup
1. Place the project in your web server's root directory.
2. Update `config/config.php` with your database credentials.
3. Access the site via `http://localhost/project-name/`.

## License
This project is open-source and free to use.