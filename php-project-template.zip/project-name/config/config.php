<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', 'password');
define('DB_NAME', 'project_db');

define('BASE_URL', 'http://localhost/project-name/');
?>