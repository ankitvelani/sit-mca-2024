<?php
include '../includes/header.php';
?>

<h1>Contact Us</h1>
<p>Please fill out the form below to get in touch with us.</p>

<?php
include '../includes/footer.php';
?>