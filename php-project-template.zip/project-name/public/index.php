<?php
include '../config/config.php';
include '../includes/header.php';
?>

<h1>Welcome to My Website</h1>

<?php
include '../includes/footer.php';
?>