<?php
include '../includes/header.php';
?>

<h1>About Us</h1>
<p>This is the about page.</p>

<?php
include '../includes/footer.php';
?>