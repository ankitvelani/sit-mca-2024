<div class="content">
<h2><?php echo $page_title; ?></h2>
<p><?php echo $page_content; ?></p>
</div>